package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
	fmt.Println("Hello, World! Azizjon")
}