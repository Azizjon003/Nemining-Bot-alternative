# Nemining-Bot-alternative

<h1> Nemiling bot database design</h1>
<a href="https://ibb.co/4SY7bPV"><img src="https://i.ibb.co/ZgYVQWM/draw-SQL-export-2022-10-18-14-47.png" alt="draw-SQL-export-2022-10-18-14-47" border="0"></a><br /><a target='_blank' href='https://ru.imgbb.com/'>бб ру</a><br />
